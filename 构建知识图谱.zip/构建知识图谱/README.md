# MiREA KG disease-layer reconstruction

这是一套根据 `neo4j.dump` 和八个疾病 CSV 反向推断出的 Neo4j 建图代码。

## 结论

脚本可重建当前输入能够支持的疾病关联层：

- `Disease`
- `Gene`
- `Microbiota`
- `Metabolite`
- `ImmuneCell`
- 四类实体关系和疾病成员关系

当前 CSV 不包含 PMID、证据句和 evidence hash，因此不能重建 dump 中的 `Article`/`Evidence` 文献证据层。详细证据见 `report/reconstruction_report.md`。

## 目录

```text
build_kg.py                    Python + Neo4j Driver 主程序
inspect_inputs.py              仅分析输入，不连接 Neo4j
schema.cypher                  约束定义
verification.cypher            导入后核验查询
disease_config.py              疾病映射、别名和阈值
load_csv/prepare_utf8_csv.py    转成 Neo4j LOAD CSV 可用的 UTF-8 文件
load_csv/load_prepared.cypher   纯 Cypher 导入方案
report/reconstruction_report.md
report/csv_profile.csv
```

## 环境

建议 Neo4j 5.26 LTS 或兼容的新版本，Python 3.10+。

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

复制 `.env.example` 为 `.env`，填写连接信息：

```env
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=你的密码
NEO4J_DATABASE=neo4j
```

## 先做 dry run

假设八个 CSV 放在 `D:\MiREA\csv`：

```bash
python build_kg.py --csv-dir "D:\MiREA\csv" --dry-run
```

按当前数据，预期输出总数：

```text
GENE_MICROBIOTA          9352
GENE_IMMUNE               727
GENE_METABOLITE           235
MICROBIOTA_METABOLITE     743
TOTAL                    11057
```

## 写入 Neo4j

```bash
python build_kg.py --csv-dir "D:\MiREA\csv"
```

脚本是幂等的：每条源关系由 `disease + source_row_id` 区分，重复运行不会重复创建同一源行。

需要先删除旧的疾病关联层再重建时：

```bash
python build_kg.py --csv-dir "D:\MiREA\csv" --reset-disease-layer
```

该参数只删除疾病层关系和 `Disease` 节点，不删除共享的 Gene/Microbiota/Metabolite/ImmuneCell，也不删除 Article/Evidence 层。

## 关键复现规则

1. CSV 使用 `GBK` 读取。
2. `GENE + Microbiota` 生成 `GENE_MICROBIOTA`，保存 `jaccard` 和 `overlap`。
3. `GENE + immune` 只保留 `p <= 0.05`，属性名为 `p_value`。
4. `GENE + Metabolite` 生成 `GENE_METABOLITE`；`change` 有值时保存。
5. `Microbiota + Metabolite` 生成 `MICROBIOTA_METABOLITE`。
6. `Node_ID = 类型前缀 + ':' + 名称小写`，保留标点、空格和 Unicode。
7. 六个基因别名归并到 `IFNG`/`TNF`，详见 `disease_config.py`。

## 纯 Cypher 方案

Neo4j `LOAD CSV` 应使用 UTF-8 文件，因此先转换：

```bash
python load_csv/prepare_utf8_csv.py \
  --csv-dir "D:\MiREA\csv" \
  --output-dir "D:\neo4j-import\prepared"
```

将生成的四个 CSV 放入 Neo4j 的 `import/prepared` 目录，然后依次运行：

```text
schema.cypher
load_csv/load_prepared.cypher
verification.cypher
```

## 关于 t2data.csv 的字符

源文件按 GBK 解码后得到 `Beta cell(汕 cell)`，而 dump 中也存储为该值。它很可能原本想表达 `Beta cell(β cell)`。主脚本默认保留 dump 的现状以实现复现；若决定清洗数据，应在源文件或预处理阶段统一修正，并记录为数据版本变更。
