# MiREA v9闭卷LLM与MiREA-RAG问答实验

## 文件

将以下文件放在同一目录：

- `MiREA_v9_llm_generated_top3.py`：完整实验主程序，包括闭卷LLM生成、Neo4j候选检索、MiREA-RAG生成、断点保存、评分和Excel导出。
- `MiREA_QA_blind_test_questions_75_v9.csv`：75道盲测问题。答案生成阶段只读取该文件，不读取金标准。
- `MiREA_QA_gold_standard_75_v9.csv`：金标准，仅在全部答案生成结束后用于评分。
- `requirements_mirea_qa.txt`：Python依赖。

完整的MiREA `*data.csv`和`*sp.csv`文件已发布在Zenodo：

`https://doi.org/10.5281/zenodo.21816834`

下载并解压后，将程序需要的`*data.csv`和`*sp.csv`文件放入主程序同级的`data/`目录。程序会利用这些文件补充文献、PMID、Jaccard、Overlap、数据集重复支持和共享代谢物证据；如果`data/`目录不存在，程序会警告并仅使用Neo4j证据，但这可能无法复现论文中的正式实验结果。

推荐目录结构：

```text
MiREA-RAG/
├── MiREA_v9_llm_generated_top3.py
├── MiREA_QA_blind_test_questions_75_v9.csv
├── MiREA_QA_gold_standard_75_v9.csv
├── requirements_mirea_qa.txt
└── data/
    ├── *data.csv
    └── *sp.csv
```

## 环境安装

建议使用Python 3.10或更高版本，并提前启动包含MiREA知识图谱的Neo4j数据库。

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux/macOS
source .venv/bin/activate

pip install -r requirements_mirea_qa.txt
```

## 运行实验

在上述目录中运行：

```bash
python MiREA_v9_llm_generated_top3.py
```

程序首先要求选择运行模式：

- 输入`run`：重新生成闭卷LLM和MiREA-RAG答案，然后评分。
- 输入`rescore`：读取已有的`checkpoint_predictions.csv`重新评分，不调用大模型，也不连接Neo4j。

选择`run`后，按提示输入：

1. 模型名称；
2. OpenAI兼容API地址；
3. API Key；
4. Neo4j地址、用户名、密码和数据库名；
5. 本次运行题数；
6. 是否继续已有断点；
7. `temperature`设置。

建议先输入`3`运行前三题，并选择不继续旧断点。确认正常后再次运行，题数直接回车以完成75题，并按需要选择继续已有断点。

API Key和Neo4j密码通过交互式隐藏输入获得，不会写入结果文件。

## v9方法说明

- 闭卷LLM和MiREA-RAG回答完全相同的75道问题，每题生成3个实体。
- 三类关系为基因–微生物、基因–代谢物和微生物–代谢物，每类25题。
- 基因–微生物最多保留30个候选；另外两类关系最多保留20个候选。
- Neo4j负责检索候选关系；基因–微生物候选还可结合MiREA来源文件中的文献、PMID、数据集、Jaccard、Overlap和共享代谢物证据。
- 提供给模型的候选证据按实体名称排序展示，避免将图谱内部排序直接作为答案顺序。
- MiREA-RAG最终答案必须由模型实际生成，并且必须出现在检索证据中；程序不会使用图谱Top-3或金标准自动补足答案。
- 当返回内容为空、格式错误、答案不足或包含证据之外的实体时，程序会尝试重新生成。
- 答案生成阶段不读取金标准。全部答案生成结束后，程序才加载金标准进行离线评分。
- 主要指标为Hit@3；同时计算Precision@3、Recall@3、F1@3、MRR@3和NDCG@3。
- 基因–微生物关系采用金标准属级实体与预测种或菌株之间的层级兼容匹配。
- Neo4j仅被查询，程序不会修改知识图谱中的节点或关系。

## 输出位置

结果保存在：

```text
model_runs/intersection_hit_at_3_v9_llm_generated_rag/<模型名称>/
```

主要输出包括：

- `checkpoint_predictions.csv`：逐题断点文件，包含原始回答、解析实体、Neo4j候选、RAG短名单、状态和错误信息，可用于续跑和重新评分。
- `run_config.json`：不含API Key和Neo4j密码的运行配置及方法版本信息。
- `MiREA_v9_llm_generated_top3_LLM_RAG评估结果.xlsx`：最终评估工作簿，包含指标汇总、逐题结果和评估说明。
